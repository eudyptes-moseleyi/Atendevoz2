# AtendeVoz

App Android que anuncia por voz quem está a ligar e atende ou desliga com o teu comando de voz.

1. Alguém liga.
2. A app diz, por exemplo: "Chamada de Maria. Diz atende ou desliga."
3. Dizes **"atende"** ou **"desliga"** e a app executa a ação.

Se o número não estiver nos contactos, diz que é um número desconhecido.

## Como abrir e instalar

1. Instala o [Android Studio](https://developer.android.com/studio).
2. Abre a pasta `AtendeVoz` (File > Open) e espera que o Gradle sincronize.
3. No telemóvel, ativa as **Opções de programador** e a **Depuração USB**
   (Definições > Sobre o telefone > toca 7 vezes na versão MIUI/HyperOS).
4. Liga o telemóvel por USB e carrega em **Run**.

## Configuração no Xiaomi (importante)

A Xiaomi fecha apps em segundo plano. Sem estes passos, a app deixa de ouvir:

1. **Arranque automático**: Definições > Apps > Gerir apps > AtendeVoz > Arranque automático (ligado).
2. **Bateria**: na mesma página, Poupança de bateria > **Sem restrições**.
3. **Fixar a app**: abre os apps recentes, toca no ícone da AtendeVoz e escolhe "Bloquear".
4. **Permissões**: Telefone, Contactos, Registo de chamadas, Microfone e Notificações.
5. **Reconhecimento de voz**: precisa da app Google (com serviços de voz) instalada e
   o português disponível. Para funcionar sem internet, descarrega o pacote offline em
   Definições > Idiomas > Introdução por voz.

## Limitações conhecidas

- **Só Android.** No iPhone não é possível.
- O toque da chamada pode atrapalhar o microfone. Funciona melhor com o toque baixo,
  em vibração ou com auscultadores.
- Depois de reiniciar o telemóvel, abre a app e carrega em **Ativar**.
- Em algumas versões do Android, a lista de contactos só chega à app se der a permissão
  "Registo de chamadas".

## Estrutura

- `MainActivity.kt`: ecrã com botão Ativar/Desativar e pedido de permissões.
- `CallListenerService.kt`: deteta a chamada, anuncia o nome, escuta e atende ou desliga.
- `AndroidManifest.xml`: permissões e serviço em primeiro plano.

## Ideias para a próxima versão

- Escolher quais os contactos que são anunciados.
- Mudar as frases e as palavras-comando.
- Anunciar também mensagens recebidas.
