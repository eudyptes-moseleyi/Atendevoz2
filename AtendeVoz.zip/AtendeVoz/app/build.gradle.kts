plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.atendevoz"
    compileSdk = 34

    defaultConfig {
        applicationId = "pt.atendevoz"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "1.1"

        // só as arquiteturas dos telemóveis atuais, para o APK ficar mais pequeno
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Reconhecimento de voz offline para o comando "liga-te" (traz o JNA sozinho)
    implementation("com.alphacephei:vosk-android:0.3.75")
}
