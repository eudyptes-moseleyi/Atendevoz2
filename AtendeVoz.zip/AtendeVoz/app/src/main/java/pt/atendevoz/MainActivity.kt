package pt.atendevoz

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var logView: TextView
    private val prefs by lazy { getSharedPreferences("atendevoz", MODE_PRIVATE) }

    private val requiredPermissions: Array<String>
        get() {
            val list = mutableListOf(
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.RECORD_AUDIO
            )
            if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
            return list.toTypedArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "AtendeVoz"
            textSize = 28f
            gravity = Gravity.CENTER_HORIZONTAL
        })

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, pad, 0, pad)
        }
        root.addView(status)

        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        root.addView(toggle)

        root.addView(TextView(this).apply {
            text = "\nNo Xiaomi, para funcionar com o ecrã desligado, ativa o arranque automático " +
                "e põe a bateria da app em \"Sem restrições\":"
            textSize = 14f
        })

        root.addView(Button(this).apply {
            text = "Arranque automático (Xiaomi)"
            setOnClickListener { openAutostart() }
        })
        root.addView(Button(this).apply {
            text = "Definições da app (bateria e permissões)"
            setOnClickListener { openAppSettings() }
        })

        root.addView(TextView(this).apply {
            text = "\nDepois de reiniciares o telemóvel, abre a app e volta a ativar."
            textSize = 14f
        })

        root.addView(TextView(this).apply {
            text = "\nRegisto (o que a app ouviu e fez na última chamada):"
            textSize = 14f
        })
        logView = TextView(this).apply {
            textSize = 12f
            setTextIsSelectable(true)
        }
        root.addView(logView)
        root.addView(Button(this).apply {
            text = "Atualizar registo"
            setOnClickListener { refresh() }
        })
        root.addView(Button(this).apply {
            text = "Limpar registo"
            setOnClickListener {
                prefs.edit().remove("log").apply()
                refresh()
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun onToggle() {
        if (prefs.getBoolean(KEY_ACTIVE, false)) {
            stopService(Intent(this, CallListenerService::class.java))
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
            refresh()
            return
        }
        val missing = requiredPermissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            startListening()
        } else {
            requestPermissions(missing.toTypedArray(), REQUEST_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_PERMISSIONS) return
        val allGranted = requiredPermissions.all {
            checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) {
            startListening()
        } else {
            status.text = "Faltam permissões. Toca em \"Definições da app\" e ativa Telefone, " +
                "Contactos, Registo de chamadas e Microfone."
        }
    }

    private fun startListening() {
        startForegroundService(Intent(this, CallListenerService::class.java))
        prefs.edit().putBoolean(KEY_ACTIVE, true).apply()
        refresh()
    }

    private fun refresh() {
        val active = prefs.getBoolean(KEY_ACTIVE, false)
        status.text = if (active) {
            "Ativo. Quando alguém ligar, digo quem é.\nDiz \"atende\" ou \"desliga\"."
        } else {
            "Desligado."
        }
        toggle.text = if (active) "Desativar" else "Ativar"
        val log = prefs.getString("log", "") ?: ""
        logView.text = if (log.isBlank()) "(vazio)" else log
    }

    private fun openAutostart() {
        try {
            startActivity(
                Intent().setComponent(
                    ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                )
            )
        } catch (_: Exception) {
            openAppSettings()
        }
    }

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_PERMISSIONS = 1
        private const val KEY_ACTIVE = "ativo"
    }
}
