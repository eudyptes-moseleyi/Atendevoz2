package pt.atendevoz

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import java.text.Normalizer
import java.util.Locale

/**
 * Serviço em primeiro plano que:
 *  1. deteta uma chamada a tocar,
 *  2. diz em voz alta quem está a ligar,
 *  3. fica à escuta de "atende" ou "desliga" e executa a ação.
 */
class CallListenerService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private var ringing = false
    private var decided = false
    private var announced = false
    private var pendingNumber: String? = null
    private var attempts = 0

    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            @Suppress("DEPRECATION")
            val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            if (state == TelephonyManager.EXTRA_STATE_RINGING) {
                onRinging(number)
            } else {
                onCallEnded()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("pt", "PT")
                tts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        handler.post { startListening() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post { startListening() }
                    }
                })
                ttsReady = true
            }
        }

        val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(phoneReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(phoneReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { unregisterReceiver(phoneReceiver) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }

    // ---------- Estado da chamada ----------

    private fun onRinging(number: String?) {
        if (!number.isNullOrBlank()) pendingNumber = number
        if (ringing) return // o Android costuma enviar este evento duas vezes

        ringing = true
        decided = false
        announced = false
        attempts = 0
        pendingNumber = number

        // pequena espera para dar tempo a chegar o segundo evento, que traz o número
        handler.postDelayed({ announce() }, 800)
    }

    private fun onCallEnded() {
        ringing = false
        announced = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        if (::tts.isInitialized) tts.stop()
    }

    private fun announce() {
        if (!ringing || announced) return
        announced = true

        val number = pendingNumber
        val name = if (number.isNullOrBlank()) null else lookupName(number)
        val text = when {
            name != null -> "Chamada de $name. Diz atende ou desliga."
            !number.isNullOrBlank() -> "Chamada de um número que não está nos contactos. Diz atende ou desliga."
            else -> "Chamada de número desconhecido. Diz atende ou desliga."
        }

        if (ttsReady) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "anuncio")
        } else {
            startListening()
        }
    }

    private fun lookupName(number: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        contentResolver.query(
            uri,
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
            null, null, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    // ---------- Reconhecimento de voz ----------

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            handleResults(partialResults)
        }

        override fun onResults(results: Bundle?) {
            if (!handleResults(results)) retryListening()
        }

        override fun onError(error: Int) {
            retryListening()
        }
    }

    private fun startListening() {
        if (!ringing || decided) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recognitionListener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recognizer?.startListening(intent)
    }

    private fun retryListening() {
        if (!ringing || decided) return
        attempts++
        if (attempts > 12) return
        handler.postDelayed({
            recognizer?.cancel()
            startListening()
        }, 500)
    }

    /** Devolve true se encontrou um comando. */
    private fun handleResults(bundle: Bundle?): Boolean {
        if (decided) return true
        val texts = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return false
        for (raw in texts) {
            when (interpret(raw)) {
                Command.ANSWER -> { decided = true; answerCall(); return true }
                Command.REJECT -> { decided = true; rejectCall(); return true }
                Command.NONE -> {}
            }
        }
        return false
    }

    private enum class Command { ANSWER, REJECT, NONE }

    private fun interpret(raw: String): Command {
        val text = Normalizer.normalize(raw.lowercase(Locale("pt", "PT")), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")

        val rejectWords = listOf("deslig", "recus", "rejeit", "cancela")
        if (rejectWords.any { text.contains(it) }) return Command.REJECT
        if (text.contains("nao atend")) return Command.REJECT

        val answerWords = listOf("atend", "aceit", "responde")
        if (answerWords.any { text.contains(it) }) return Command.ANSWER

        return Command.NONE
    }

    // ---------- Ações sobre a chamada ----------

    private fun answerCall() {
        stopSpeechAndListening()
        try {
            getSystemService(TelecomManager::class.java).acceptRingingCall()
        } catch (_: SecurityException) {
        }
    }

    private fun rejectCall() {
        stopSpeechAndListening()
        try {
            getSystemService(TelecomManager::class.java).endCall()
        } catch (_: SecurityException) {
        }
    }

    private fun stopSpeechAndListening() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        if (::tts.isInitialized) tts.stop()
    }

    // ---------- Notificação em primeiro plano ----------

    private fun startAsForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Escuta de chamadas", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("AtendeVoz ativo")
            .setContentText("À espera de chamadas")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val CHANNEL_ID = "atendevoz_escuta"
        private const val NOTIFICATION_ID = 1
    }
}
