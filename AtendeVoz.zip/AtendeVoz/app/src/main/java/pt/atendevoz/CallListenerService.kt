package pt.atendevoz

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Serviço em primeiro plano que:
 *  1. deteta uma chamada a tocar,
 *  2. diz em voz alta quem está a ligar,
 *  3. fica à escuta de "atende" ou "desliga" e executa a ação.
 *
 * Versão 2: regista na notificação e no ecrã da app o que se passa (para diagnóstico).
 */
class CallListenerService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private var ringing = false
    private var decided = false
    private var announced = false
    private var pendingNumber: String? = null
    private var attempts = 0

    private lateinit var wakeEngine: WakeWordEngine
    private var cpuLock: PowerManager.WakeLock? = null

    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            @Suppress("DEPRECATION")
            val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            if (state == TelephonyManager.EXTRA_STATE_RINGING) {
                onRinging(number)
            } else {
                onCallEnded(state)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        log("Serviço iniciado")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("pt", "PT")
                tts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        handler.post { startListening() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post {
                            log("Erro na voz que fala (TTS)")
                            startListening()
                        }
                    }
                })
                ttsReady = true
            } else {
                log("A voz que fala (TTS) não arrancou")
            }
        }

        val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(phoneReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(phoneReceiver, filter)
        }

        // comando "liga-te": acorda o ecrã quando ouve a frase
        wakeEngine = WakeWordEngine(this, { message -> log(message) }, { wakeScreen() })
        if (wakeWordEnabled()) {
            // mantém o processador ativo para continuar a ouvir com o ecrã desligado
            val pm = getSystemService(PowerManager::class.java)
            cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AtendeVoz:escuta").apply {
                setReferenceCounted(false)
                acquire()
            }
            wakeEngine.start()
        }
    }

    private fun wakeWordEnabled(): Boolean =
        getSharedPreferences("atendevoz", MODE_PRIVATE).getBoolean("liga_te", true)

    private fun wakeScreen() {
        val pm = getSystemService(PowerManager::class.java)
        @Suppress("DEPRECATION")
        val lock = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                PowerManager.ACQUIRE_CAUSES_WAKEUP or
                PowerManager.ON_AFTER_RELEASE,
            "AtendeVoz:ecra"
        )
        lock.acquire(8000)
        log("Ouvi \"liga-te\": ecrã ligado")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { unregisterReceiver(phoneReceiver) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        if (::wakeEngine.isInitialized) wakeEngine.stop()
        cpuLock?.let { if (it.isHeld) it.release() }
        cpuLock = null
        log("Serviço parado")
        super.onDestroy()
    }

    // ---------- Estado da chamada ----------

    private fun onRinging(number: String?) {
        // liberta o microfone para o reconhecimento de "atende" e "desliga"
        wakeEngine.stop()
        if (!number.isNullOrBlank()) pendingNumber = number
        if (ringing) return // o Android costuma enviar este evento duas vezes

        ringing = true
        decided = false
        announced = false
        attempts = 0
        pendingNumber = number
        log("Chamada a tocar")

        // pequena espera para dar tempo a chegar o segundo evento, que traz o número
        handler.postDelayed({ announce() }, 800)
    }

    private fun onCallEnded(state: String) {
        // só volta a ouvir "liga-te" quando já não há nenhuma chamada
        if (state == TelephonyManager.EXTRA_STATE_IDLE) {
            if (wakeWordEnabled()) wakeEngine.start()
        } else {
            wakeEngine.stop()
        }
        if (ringing) log("Chamada terminou ($state)")
        ringing = false
        announced = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        if (::tts.isInitialized) tts.stop()
    }

    private fun announce() {
        if (!ringing || announced) return
        announced = true

        val number = pendingNumber
        val name = if (number.isNullOrBlank()) null else lookupName(number)
        val text = when {
            name != null -> "Chamada de $name. Atende ou desliga?"
            !number.isNullOrBlank() -> "Número desconhecido. Atende ou desliga?"
            else -> "Número desconhecido. Atende ou desliga?"
        }
        log("A anunciar: ${name ?: number ?: "sem número"}")

        if (ttsReady) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "anuncio")
        } else {
            startListening()
        }
    }

    private fun lookupName(number: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        contentResolver.query(
            uri,
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
            null, null, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    // ---------- Reconhecimento de voz ----------

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            log("Pode falar (microfone aberto)")
        }
        override fun onBeginningOfSpeech() {
            log("Ouvi voz a começar")
        }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            handleResults(partialResults, partial = true)
        }

        override fun onResults(results: Bundle?) {
            if (!handleResults(results, partial = false)) retryListening()
        }

        override fun onError(error: Int) {
            log("Erro de voz: ${errorName(error)}")
            // estes erros pedem um reconhecedor novo
            if (error == SpeechRecognizer.ERROR_CLIENT ||
                error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
            ) {
                recognizer?.destroy()
                recognizer = null
            }
            retryListening()
        }
    }

    private fun errorName(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "sem rede (timeout)"
        SpeechRecognizer.ERROR_NETWORK -> "sem rede"
        SpeechRecognizer.ERROR_AUDIO -> "erro de áudio / microfone ocupado"
        SpeechRecognizer.ERROR_SERVER -> "erro do servidor"
        SpeechRecognizer.ERROR_CLIENT -> "erro do cliente"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "não ouvi ninguém falar"
        SpeechRecognizer.ERROR_NO_MATCH -> "não percebi o que disseste"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "reconhecedor ocupado"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "falta permissão do microfone"
        else -> "código $error"
    }

    private fun startListening() {
        if (!ringing || decided) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("Este telemóvel não tem reconhecimento de voz (instala/atualiza a app Google)")
            return
        }

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recognitionListener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            // modelo para frases curtas, e dica ao reconhecedor sobre as palavras esperadas
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra("android.speech.extra.BIASING_STRINGS", arrayListOf("atende", "desliga"))
            // deixa o microfone aberto mais tempo antes de desistir
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        log("A abrir o microfone (tentativa ${attempts + 1})")
        recognizer?.startListening(intent)
    }

    private fun retryListening() {
        if (!ringing || decided) return
        attempts++
        if (attempts > 12) {
            log("Desisti de ouvir (12 tentativas)")
            return
        }
        handler.postDelayed({
            recognizer?.cancel()
            startListening()
        }, 250)
    }

    /** Devolve true se encontrou um comando. */
    private fun handleResults(bundle: Bundle?, partial: Boolean): Boolean {
        if (decided) return true
        val texts = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (texts.isNullOrEmpty()) return false

        log("Ouvi${if (partial) " (parcial)" else ""}: ${texts.joinToString(" | ")}")

        for (raw in texts) {
            when (interpret(raw)) {
                Command.ANSWER -> { decided = true; answerCall(); return true }
                Command.REJECT -> { decided = true; rejectCall(); return true }
                Command.NONE -> {}
            }
        }
        return false
    }

    private enum class Command { ANSWER, REJECT, NONE }

    private fun interpret(raw: String): Command {
        val text = Normalizer.normalize(raw.lowercase(Locale("pt", "PT")), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z ]"), "")
        // sem espaços, para apanhar "de liga" ou "a tende" ouvidos em duas partes
        val joined = text.replace(" ", "")

        val rejectWords = listOf(
            "desliga", "desligar", "desligue", "recusa", "recusar", "rejeita", "rejeitar", "cancela"
        )
        val answerWords = listOf("atende", "atender", "atenda", "aceita", "aceitar", "responde")

        val wantsReject = rejectWords.any { fuzzyContains(joined, it) }
        val wantsAnswer = answerWords.any { fuzzyContains(joined, it) }
        val negated = joined.contains("naoatend") || joined.contains("naoaceit")

        return when {
            wantsReject || negated -> Command.REJECT
            wantsAnswer -> Command.ANSWER
            else -> Command.NONE
        }
    }

    /** Procura [target] dentro de [text], aceitando um erro de uma letra (para quando ouve mal). */
    private fun fuzzyContains(text: String, target: String): Boolean {
        if (text.contains(target)) return true
        for (len in (target.length - 1)..(target.length + 1)) {
            if (len > text.length) continue
            for (start in 0..(text.length - len)) {
                if (editDistance(text.substring(start, start + len), target) <= 1) return true
            }
        }
        return false
    }

    private fun editDistance(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val current = IntArray(b.length + 1)
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + cost)
            }
            previous = current
        }
        return previous[b.length]
    }

    // ---------- Ações sobre a chamada ----------

    private fun answerCall() {
        stopSpeechAndListening()
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            log("FALHOU atender: falta a permissão de atender chamadas (Telefone)")
            return
        }
        try {
            getSystemService(TelecomManager::class.java).acceptRingingCall()
            log("Comando enviado: ATENDER")
        } catch (e: SecurityException) {
            log("FALHOU atender: sem permissão (${e.message})")
        } catch (e: Exception) {
            log("FALHOU atender: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    private fun rejectCall() {
        stopSpeechAndListening()
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            log("FALHOU desligar: falta a permissão de atender chamadas (Telefone)")
            return
        }
        try {
            val ended = getSystemService(TelecomManager::class.java).endCall()
            log("Comando enviado: DESLIGAR (resultado: $ended)")
        } catch (e: SecurityException) {
            log("FALHOU desligar: sem permissão (${e.message})")
        } catch (e: Exception) {
            log("FALHOU desligar: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    private fun stopSpeechAndListening() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        if (::tts.isInitialized) tts.stop()
    }

    // ---------- Registo e notificação ----------

    private var builder: Notification.Builder? = null

    private fun log(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val line = "$time $message"

        // guarda as últimas 40 linhas para mostrar no ecrã da app
        val prefs = getSharedPreferences("atendevoz", MODE_PRIVATE)
        val old = prefs.getString("log", "") ?: ""
        val lines = (old.split("\n").filter { it.isNotBlank() } + line).takeLast(40)
        prefs.edit().putString("log", lines.joinToString("\n")).apply()

        // mostra a linha mais recente na notificação
        val b = builder ?: return
        b.setContentText(message)
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, b.build())
    }

    private fun startAsForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Escuta de chamadas", NotificationManager.IMPORTANCE_LOW)
        )
        val b = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("AtendeVoz ativo")
            .setContentText("À espera de chamadas")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setStyle(Notification.BigTextStyle())
            .setOnlyAlertOnce(true)
            .setOngoing(true)
        builder = b
        val notification = b.build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val CHANNEL_ID = "atendevoz_escuta"
        private const val NOTIFICATION_ID = 1
    }
}
