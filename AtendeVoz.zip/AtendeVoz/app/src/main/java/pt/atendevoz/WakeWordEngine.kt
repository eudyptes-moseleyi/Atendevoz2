package pt.atendevoz

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Escuta, sempre no telemóvel (sem enviar áudio para a internet), a frase "liga-te".
 *
 * Usa o Vosk com um modelo pequeno em português. O modelo (cerca de 30 MB) é
 * descarregado uma só vez, na primeira ativação.
 */
class WakeWordEngine(
    private val context: Context,
    private val log: (String) -> Unit,
    private val onWake: () -> Unit,
    private val onTime: () -> Unit
) {
    private val main = Handler(Looper.getMainLooper())

    private var model: Model? = null
    private var speech: SpeechService? = null
    private var starting = false
    private var wanted = false
    private var lastWake = 0L
    private var lastTime = 0L

    /** Começa (ou retoma) a escuta. */
    fun start() {
        wanted = true
        if (speech != null || starting) return
        starting = true

        Thread {
            try {
                if (model == null) {
                    val dir = ensureModel()
                    if (dir == null) {
                        main.post { starting = false }
                        return@Thread
                    }
                    model = Model(dir.absolutePath)
                }
                main.post { openRecognizer() }
            } catch (e: Exception) {
                log("Erro ao preparar o \"liga-te\": ${e.message}")
                main.post { starting = false }
            }
        }.start()
    }

    /** Pára a escuta e liberta o microfone (por exemplo, durante uma chamada). */
    fun stop() {
        wanted = false
        val service = speech ?: return
        speech = null
        try {
            service.stop()
            service.shutdown()
        } catch (_: Exception) {
        }
    }

    private fun openRecognizer() {
        starting = false
        val m = model ?: return
        if (!wanted || speech != null) return
        try {
            // só procura as frases "liga te" e "que horas são"; tudo o resto é ignorado
            val recognizer = Recognizer(
                m, SAMPLE_RATE, "[\"liga te\", \"que horas são\", \"[unk]\"]"
            )
            val service = SpeechService(recognizer, SAMPLE_RATE)
            service.startListening(listener)
            speech = service
            log("À escuta de \"liga-te\"")
        } catch (e: Exception) {
            log("Não consegui abrir o microfone para o \"liga-te\": ${e.message}")
        }
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) = check(hypothesis, "partial")
        override fun onResult(hypothesis: String?) = check(hypothesis, "text")
        override fun onFinalResult(hypothesis: String?) {}
        override fun onError(exception: Exception?) {
            log("Erro na escuta do \"liga-te\": ${exception?.message}")
        }
        override fun onTimeout() {}
    }

    private fun check(hypothesis: String?, key: String) {
        if (hypothesis.isNullOrBlank()) return
        val text = try {
            JSONObject(hypothesis).optString(key, "")
        } catch (_: Exception) {
            ""
        }
        val now = System.currentTimeMillis()

        // evita disparar várias vezes seguidas com a mesma frase
        if (text.contains("liga te")) {
            if (now - lastWake < 4000) return
            lastWake = now
            onWake()
        } else if (text.contains("que horas")) {
            if (now - lastTime < 6000) return
            lastTime = now
            onTime()
        }
    }

    // ---------- Modelo de voz ----------

    private fun ensureModel(): File? {
        val root = File(context.filesDir, "vosk")
        val ready = File(root, "model-pt")
        if (File(ready, "am").exists()) return ready

        log("A descarregar o modelo de voz (cerca de 30 MB). Precisa de internet.")
        try {
            root.mkdirs()
            val zip = File(root, "model.zip")
            val tmp = File(root, "tmp")
            tmp.deleteRecursively()
            tmp.mkdirs()

            download(MODEL_URL, zip)
            unzip(zip, tmp)
            zip.delete()

            val found = tmp.walkTopDown().firstOrNull { it.isDirectory && File(it, "am").exists() }
            if (found == null) {
                log("Modelo de voz inválido depois de descarregar")
                tmp.deleteRecursively()
                return null
            }
            ready.deleteRecursively()
            if (!found.renameTo(ready)) {
                log("Não consegui guardar o modelo de voz")
                return null
            }
            tmp.deleteRecursively()
            log("Modelo de voz pronto")
            return ready
        } catch (e: Exception) {
            log("Falhou o descarregamento do modelo: ${e.message}")
            return null
        }
    }

    private fun download(url: String, target: File) {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.instanceFollowRedirects = true
        connection.inputStream.use { input ->
            FileOutputStream(target).use { output -> input.copyTo(output) }
        }
        connection.disconnect()
    }

    private fun unzip(zip: File, targetDir: File) {
        val base = targetDir.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                val out = File(targetDir, entry.name)
                // segurança: não deixa o zip escrever fora da pasta de destino
                if (!out.canonicalPath.startsWith(base)) continue
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
            }
        }
    }

    companion object {
        private const val SAMPLE_RATE = 16000.0f
        private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip"
    }
}
